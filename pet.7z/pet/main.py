s = input("Введите строку")
x = ""
for i in range(len(s)):
       if s[i] == ",": x = x + "ю"
       elif s[i] == "ю": x = x + ","
       else: x = x+s[i]
print(x)
