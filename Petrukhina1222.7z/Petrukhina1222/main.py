try:
numberA, znak, numberB = [i for i in input('Введите математическое вырожение (число операнд число):').split()]
except ValueError:
print('неправельный ввод')
continue
numberA = int(numberA)
numberB = int(numberB)

if znak == "0" :
    break
elif znak == "+":
    print(f'{numberA} {znak} {numberB} = {numberA + numberB}')
elif znak == "-":
    print(f'{numberA} {znak} {numberB} = {numberA - numberB}')
elif znak == "*":
    print(f'{numberA} {znak} {numberB} = {numberA * numberB}')
elif znak == "/":
    try:
    print(f'{numberA} {znak} {numberB} = {numberA / numberB}')
    except  ZeroDivisionError:
    print('Ошибка. Деление на ноль')





