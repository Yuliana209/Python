
def func(n, a=0, b=0):
    n, d = divmod(n, 10)
    a += d % 2
    b += not d % 2
    return (a, b) if not n else func(n, a, b)

while True:
    n = int(input('n  ='))
    print(f'количество четных и нечетных цифр в числе {n} равно: {func(n)}\n ')
